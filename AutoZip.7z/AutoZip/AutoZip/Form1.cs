﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AutoZip.Properties;

namespace AutoZip
{
    public partial class Form1 : Form
    {
        private bool threadStart = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fd = new FolderBrowserDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                txbPath.Text = fd.SelectedPath;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            threadStart = true;
            int interval = int.Parse(textBox2.Text)*60*1000;
            TimerThread(interval);

            btnStart.Visible = false;
            btnStop.Visible = true;
        }

        private void SpinWait(int delay_ms)
        {
            long st_ticks = DateTime.Now.Ticks;
            while (true)
            {
                long wait_diff = (DateTime.Now.Ticks - st_ticks) / TimeSpan.TicksPerMillisecond;
                if (wait_diff > delay_ms) break;

                Thread.Sleep(1);
            }
        }

        private void TimerThread(int interval)
        {
            Task.Factory.StartNew(() =>
            {
                while (threadStart)
                {
                    SpinWait(interval);

                    int logIndex = int.Parse(textBox1.Text);
                    string findFileName = "." + logIndex;

                    while (zip.FindFileThenCopy(txbPath.Text, findFileName, "*" + findFileName))
                    {
                        findFileName = "." + ++logIndex;
                    }
                    zip.ZipAllFile();

                }
            });
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Settings.Default.Path = txbPath.Text;
            Settings.Default.LogIndex = textBox1.Text;
            Settings.Default.Period = textBox2.Text;
            Settings.Default.Save();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txbPath.Text = Settings.Default.Path;
            textBox1.Text = Settings.Default.LogIndex;
            textBox2.Text = Settings.Default.Period;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            threadStart = false;

            btnStart.Visible = true;
            btnStop.Visible = false;
        }

    }
}
