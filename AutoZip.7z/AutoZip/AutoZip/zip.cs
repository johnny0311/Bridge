﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace AutoZip
{
    class zip
    {
        /*
          try
                    {
                        zip.FindFileThenZip(System.Windows.Forms.Application.StartupPath + @"\LogFiles\", DateTime.Now.ToString("yyyyMMdd"), "*log");                    
                        zip.FindFileThenZip(System.Windows.Forms.Application.StartupPath + @"\LogFiles\", DateTime.Now.AddDays(-1).ToString("yyyyMMdd"), "*log");//要加這個來處理23:00沒壓縮的問題
                        zip.DeleteFile(System.Windows.Forms.Application.StartupPath + @"\LogFiles\", DateTime.Now.AddDays(-12).ToString("yyyyMMdd"), "*.zip");
                        zip.DeleteFile(System.Windows.Forms.Application.StartupPath + @"\LogFiles\", DateTime.Now.AddDays(-12).ToString("yyyyMMdd"), "*.csv");
                    }
                    catch (Exception ex)
                    {
                        AppendLog("e1" + ex.ToString());
                    }
             
             
             */


        public static List<string> zipList = new List<string>();
        public static List<string> FindFileList = new List<string>();
        /// <summary>
        /// 壓縮檔案
        /// </summary>
        /// <param name="sourceFile"></param>
        public static void CreateZipArchive1(string sourceFile)
        {
            try
            {
                string workPath = Path.GetDirectoryName(sourceFile);
                string createEntryFileName = Path.GetFileName(sourceFile);
                string targetZipFileName = string.Format("{0}{1}", Path.GetFileNameWithoutExtension(sourceFile), ".zip");
                string distinationFile = Path.Combine(workPath, targetZipFileName);

                using (FileStream f = new FileStream(sourceFile, FileMode.Open, FileAccess.Read))
                {


                    using (var fileStream = new FileStream(distinationFile, FileMode.CreateNew))
                    {
                        using (var archive = new ZipArchive(fileStream, ZipArchiveMode.Create, true))
                        {
                            byte[] xlsxBytes = BinaryUtil.BinaryReadToEnd(f);

                            var zipArchiveEntry = archive.CreateEntry(createEntryFileName, CompressionLevel.Fastest);
                            BinaryReader bs = new BinaryReader(f);

                            using (var zipStream = zipArchiveEntry.Open())
                            {
                                zipStream.Write(xlsxBytes, 0, xlsxBytes.Length);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine("supersu " + ex.ToString());

                throw;
            }


        }

        public static void CreateZipArchive(string sourceFile)
        {
            try
            {
                string workPath = Path.GetDirectoryName(sourceFile);
                string createEntryFileName = Path.GetFileName(sourceFile);
                string targetZipFileName = string.Format("{0}{1}", Path.GetFileNameWithoutExtension(sourceFile), ".zip");
                string distinationFile = Path.Combine(workPath, targetZipFileName);

                if (File.Exists(distinationFile)) return;

                using (ZipArchive zip = ZipFile.Open(distinationFile, ZipArchiveMode.Create))
                {
                        zip.CreateEntryFromFile(sourceFile,createEntryFileName);
                }      
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine("supersu " + ex.ToString());

                throw;
            }


        }
        /// <summary>
        /// 壓縮檔案(除了正在使用的檔案)
        /// </summary>
        /// <param name="dir"></param>
        /// <param name="findText"></param>
        /// <param name="filenameExtension"></param>
        public static void FindFileThenZip(string dir, string findText, string filenameExtension)
        {
            try
            {
                FindFileList.Clear();
                zip.FindFile(dir, findText, filenameExtension);

                List<Task> TaskList = new List<Task>();
                List<string> tempList = new List<string>();

                if (FindFileList.Count > 1)
                {
                    tempList = FindFileList.GetRange(0, FindFileList.Count - 1);

                    foreach (var text in tempList)
                    {
                        Task task = new Task(() =>
                         {
                             zip.CreateZipArchive(text);
                         });
                        task.Start();
                        TaskList.Add(task);
                    }
                    Task.WaitAll(TaskList.ToArray(), -1);
                    foreach (string file in tempList)
                    {
                        File.Delete(file);
                    }
                }
                else
                {
                    if (FindFileList.Count > 0 && FindFileList[0].Substring(FindFileList[0].Length - 6, 2) == "23"&&findText==DateTime.Now.AddDays(-1).ToString("yyyyMMdd"))//昨天的才要壓縮23點
                    {
                        tempList = FindFileList.GetRange(0, FindFileList.Count);


                        foreach (var text in tempList)
                        {
                            Task task = new Task(() =>
                             {
                                 zip.CreateZipArchive(text);
                             });
                            task.Start();
                            TaskList.Add(task);
                        }
                        Task.WaitAll(TaskList.ToArray(), -1);
                        foreach (string file in tempList)
                        {
                            File.Delete(file);
                        }

                    }
                }
            }
            catch { throw; }
        }
        /// <summary>
        /// 壓縮找到並複製完的所有檔案
        /// </summary>
        public static void ZipAllFile()
        {
            List<Task> TaskList = new List<Task>();
            if (zipList.Count <= 0) return;

            foreach (var text in zipList)
            {
                Task task = new Task(() =>
                {
                    zip.CreateZipArchive(text);
                });
                task.Start();
                TaskList.Add(task);
            }
            Task.WaitAll(TaskList.ToArray(), -1);
            foreach (string file in zipList)
            {
                File.Delete(file);
            }
            zipList.Clear();
        }
        /// <summary>
        /// 尋找檔案並複製
        /// </summary>
        /// <param name="dir">路徑</param>
        /// <param name="findText">尋找文字</param>
        /// <param name="filenameExtension">尋找附檔名</param>
        public static bool FindFileThenCopy(string dir, string findText, string filenameExtension)
        {
            try
            {
                FindFileList.Clear();
                zip.FindFile(dir, findText, filenameExtension);
                if (FindFileList.Count <= 0) return false ;
                foreach (var item in FindFileList)
                {
                    //DateTime last = File.GetLastAccessTime(item);
                    DateTime last = File.GetLastAccessTime(item);
                    string FileName = string.Format(@"{0}_{1}.log", item.Split('.')[0], last.ToString("yyyyMMdd_HHmm"));
                    if (!File.Exists(FileName) && !File.Exists(FileName.Split('.')[0]+".zip"))
                    {
                        zipList.Add(FileName);
                        File.Copy(item, FileName);
                    }
                }
                return true;
            }
            catch
            {
                throw;
            }
        }

        public static void FindFile(string dir, string findText, string filenameExtension)
        {
            //在指定目錄下查詢文件，若符合查詢條件，將檔案寫入lsFile控制元件

            DirectoryInfo Dir = new DirectoryInfo(dir);
            try
            {
                //foreach (DirectoryInfo d in Dir.GetDirectories())//查詢子目錄    
                //{
                //    FindFile(Dir + d.ToString() + "\\", findText, filenameExtension);
                //}
                foreach (FileInfo f in Dir.GetFiles(filenameExtension))//查詢附檔名為filenameExtension的文件
                {
                    Regex regex = new Regex(findText);//查詢檔案名稱中有關鍵字findText的文件
                    Match m = regex.Match(f.ToString());
                    if (m.Success == true)
                    {
                            FindFileList.Add(Dir + "\\" + f.ToString());
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        public static void DeleteFile(string dir, string findText, string filenameExtension)
        {

            DirectoryInfo Dir = new DirectoryInfo(dir);
            var tempList = new List<string>();
            foreach (FileInfo f in Dir.GetFiles(filenameExtension))//查詢附檔名為xls的文件 "*.xls" 
            {
                Regex regex = new Regex(findText);//查詢檔案名稱中有關鍵字friend的文件
                Match m = regex.Match(f.ToString());
                if (m.Success == true)
                {
                    tempList.Add(Dir + f.ToString());
                }
            }

            foreach (string file in tempList)
            {
                File.Delete(file);
            }
        }
               
    }

    class BinaryUtil
    {
        public static byte[] BinaryReadToEnd(Stream stream)
        {

            long originalPosition = 0;
            try
            {
                if (stream.CanSeek)
                {
                    originalPosition = stream.Position;
                    stream.Position = 0;
                }


                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            catch(Exception ex)
            {
                System.Diagnostics.Trace.WriteLine("supersu " + ex.ToString());
                throw;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }
    }
}
