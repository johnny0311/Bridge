﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;

namespace LogFilterParser
{
    public partial class Form1 : Form
    {
        Dictionary<int, string> data = new Dictionary<int, string>();
        List<int> list = new List<int>();
        int index = 0;
        int trustCycle = 0;
        string path = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxStatus.SelectedIndex = 0;
            cbxChannel.SelectedIndex = 0;
            cbxBridge.SelectedIndex = 0;
            cbxLocation.SelectedIndex = 0;
        }

        private string selBridge()
        {
            if (cbxBridge.SelectedIndex == 0)
                return "9C431E500120";
            else
                return "9C431E500121";
        }

        private void logParsing(string s)
        {
            try
            {
                //2018-12-11 13:46:44,253 [1] INFO  RawLog - RAW - S,9C431E500120,98072D4B1937,-44,0,94,0,1*1D
                string time = s.Split('[')[0];
                string rssi = s.Split('[')[1].Split(',')[3];

                list.Add(int.Parse(rssi));
                data.Add(list.Count, time);
            }
            catch (Exception)
            {

            }

        }

        private void scanLimit(float rssi, int index)
        {
            if (rssi / trustCycle > int.Parse(txbScanLimit.Text))
            {
                foreach (var item in data)
                {
                    if (item.Key == index)
                    {
                        richTextBox1.AppendText(string.Format("{0} | {1}\r\n", item.Value, rssi / trustCycle));
                    }
                }

            }
        }

        private void stringFilter(StringBuilder sb, string filter, string s)
        {
            if (s.Contains(string.Format("{0},{1}",filter,txbFilter.Text)))
            {
                string selCh = cbxChannel.SelectedItem.ToString();
                string selStatus = cbxStatus.SelectedItem.ToString();

                if (selCh.Equals("0") && !s.Contains(",0*") || selCh.Equals("1") && !s.Contains(",1*"))
                    return;

                if (selStatus.Equals("Static") && s.Contains(",1,") || selStatus.Equals("Move") && !s.Contains(",1,"))
                    return;

                sb.Append(string.Format("{0}\r\n", s.ToString()));
            }
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            fd.Filter = "*.log|*log";
            if (fd.ShowDialog() == DialogResult.OK)
            {
                txbPath.Text = fd.FileName;
                path = txbPath.Text;
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            if (path.Equals(""))
            {
                MessageBox.Show("You didn't choose Log");
                return;
            }
            FileStream fs = new FileStream(path,FileMode.Open,FileAccess.Read);
            
            progressBar1.Maximum = (int)fs.Length;
            int readLen = 0;
            StringBuilder sb = new StringBuilder();
            
            using (StreamReader sr = new StreamReader(fs))
            {
                while (sr.Peek() != -1)
                {
                    string s = sr.ReadLine();
                    if (s.Equals(""))
                        readLen += 2;
                    else
                        readLen += s.Length;
                    switch (cbxLocation.SelectedIndex)
                    {
                        case 0:
                            stringFilter(sb, "9C431E500116", s);
                            stringFilter(sb, "9C431E500117", s);
                            break;
                        case 1:
                            stringFilter(sb, "9C431E500122", s);
                            break;
                        case 2:
                            stringFilter(sb, "9C431E500123", s);
                            break;
                        case 3:
                            stringFilter(sb, "9C431E500120", s);
                            stringFilter(sb, "9C431E500121", s);
                            break;
                    }
                   
                    progressBar1.Value = readLen;

                }
                progressBar1.Value = progressBar1.Maximum;
                richTextBox1.Text = sb.ToString();
                
            }
            sb.Clear();

            MessageBox.Show("Success");
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (path.Equals(""))
            {
                MessageBox.Show("You didn't choose Log");
                return;
            }

            string filterString = string.Format("{0},{1}", selBridge(), textBox1.Text);
            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);

            progressBar1.Maximum = (int)fs.Length;
            int readLen = 0;
            StringBuilder sb = new StringBuilder();

            using (StreamReader sr = new StreamReader(fs))
            {
                while (sr.Peek() != -1)
                {
                    string s = sr.ReadLine();
                    if (s.Equals(""))
                        readLen += 2;
                    else
                        readLen += s.Length;

                    if (s.Contains(filterString) && s.Contains(",1*"))
                    {
                        sb.Append(string.Format("{0}\r\n", s.ToString()));
                    }

                    progressBar1.Value = readLen;

                }
                progressBar1.Value = progressBar1.Maximum;


                trustCycle = int.Parse(txbCount.Text);
                index = 0;
                list.Clear();
                data.Clear();
                richTextBox1.Text = "";

                string[] strlist = sb.ToString().Split('\n');
                foreach (var item in strlist)
                {
                    logParsing(item);
                }

                for (int i = 0; i < list.Count; i++)
                {
                    if (index + trustCycle > list.Count)
                    {
                        break;
                    }
                    float RSSI = 0;
                    for (int j = 0; j < trustCycle; j++)
                    {
                        RSSI += list[index + j];
                    }
                    index = index + 1;

                    scanLimit(RSSI, index);
                }

            }

            sb.Clear();

            MessageBox.Show("Success");
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(richTextBox1.Text);
                MessageBox.Show("Copy to Clipboard Success");
            }
            catch (Exception)
            {
                MessageBox.Show("Result is null");
            }
            
        }

        Dictionary<string, CheckPointData> dic = new Dictionary<string, CheckPointData>();
        int[] num = { -45, -46, -46, -47, -48, -49, -50, -51, -52, -53};
        string[] device = {"device1","device2","device3"};
        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            Random r = new Random();
            string uuid = device[r.Next(0,2)];
            int rssi = num[r.Next(0, 10)];
            if (!dic.ContainsKey(uuid))
            {
                CheckPointData c = new CheckPointData();
                c.timeWindows(uuid,rssi);
                dic.Add(uuid,c);
            }
            else
            {
                string AGVTag = dic[uuid].timeWindows(uuid, rssi);
                
                if (!AGVTag.Equals(""))
                    richTextBox1.AppendText(string.Format("{0}\r\n", AGVTag));
            }

            foreach (var item in dic)
            {
                if (item.Value.rssiList.Count == 4)
                {
                    richTextBox1.AppendText(string.Format("===== {0} =====\r\n", item.Value.UUID));
                    foreach (var value in item.Value.rssiList)
                    {
                        richTextBox1.AppendText(string.Format("{0}\r\n", value));
                    }
                }
                
            }
            
        }
    }
}
