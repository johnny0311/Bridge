﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace LogFilterParser
{
    class CheckPointData
    {
        public List<int> rssiList = new List<int>();
        public string UUID = "";
        public string AGVTag = "";
        int scanLimit = -47;

        public string timeWindows(string uuid, int rssi)
        {
            UUID = uuid;
            Trace.WriteLine(string.Format("Insert {0} : {1}", uuid, rssi));
            rssiList.Add(rssi);

            if (rssiList.Count > 4)
            {
                rssiList.RemoveAt(0);
            }
            if (rssiList.Count == 4)
            {
                foreach (var item in rssiList)
                {
                    Trace.WriteLine(item.ToString());
                }
                Trace.WriteLine("=======================");
                Trace.WriteLine(string.Format("Average SNR = {0}", rssiList.Average()));
                if (rssiList.Average() > scanLimit)
                {
                    AGVTag = uuid;
                    Trace.WriteLine(string.Format("AGV Tag = {0}", AGVTag));
                    return UUID;
                }
                else
                {
                    AGVTag = "";
                    Trace.WriteLine("AGV Tag not found");
                    return "";
                }
            }
            return "";
        }
    }
}
